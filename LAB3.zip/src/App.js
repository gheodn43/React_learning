import './App.css';
import DataComponent from './components/DataComponent';
function App() {
  return (
    <div className='bg-light min-vh-100'>
      <DataComponent />
    </div>
  );
}

export default App;
